package com.example.jpe.healthtechproject.BluetoothLE;
/**
 * Created by jpe on 1.3.2018.
 */

// HR example code
import android.app.Activity;
import android.app.Application;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;

import com.example.jpe.healthtechproject.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;


public class PolarBluetoothLE extends /*Application,*/ Activity  implements  AdapterView.OnItemClickListener {


    private BluetoothAdapter bluetoothAdapter;
    private BluetoothManager btManager;
    private Context context;


    private Button btn_Scan;


    private TextView textViewHR;

    private int hrRate;
    private int hrCounter = 0;


    private int scanAllCounter = 0;
    private int scanMaxCounter = 15; //sec

    private ListAdapter_BTLE_Devices adapter;
    private ListView listView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Set layout.
        setContentView(R.layout.activity_polar_bluetooth_le);

        btn_Scan = (Button) findViewById(R.id.btn_scan);


        adapter = new ListAdapter_BTLE_Devices(this,
                                R.layout.btle_device_list_item,
                                BluetoothLEHandler.getInstance().GetBluetoothDevices());



        listView = new ListView(this);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(this);

        ((ScrollView) findViewById(R.id.scrollViewBTLE)).addView(listView);

        textViewHR = (TextView) findViewById(R.id.hr_text2);
        UpdateHRRate(0);
        hrRate = 0;
        PulseTask();
    }

    public void StartBluetoothScan(View view) {

        //ScanAllBTDevices = BT_SCAN_ALL ;
        scanAllCounter = 0;
        //int count = 0;
        btn_Scan.setText("Scanning...");

         BluetoothLEHandler.getInstance().StartBluetoothLEScan(10000);
        listView.setAdapter(adapter); // set empty list


        new CountDownTimer(10000, 1000) {

            public void onTick(long millisUntilFinished) {
                //count++;
                //btn_Scan.setText("Scanning..." + String.valueOf(count) + "/10 sec" );
            }
            public void onFinish(){
                StopBluetoothScan();
            }
        }.start();



    }

    public void StopBluetoothScan() {

        btn_Scan.setText("Scan Again");
        BluetoothLEHandler.getInstance().StopBluetoothLEScan();
        listView.setAdapter(adapter);

        //ScanAllBTDevices = BT_NONE;
    }

    public void UpdateHRRate(int newRate) {
        hrCounter = 0;
        hrRate = newRate;
    }
    public String GetHRRate(){
        String temp =  String.valueOf(hrRate);
        return temp;
    }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {


      //  listView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
      //  listView.setItemChecked(position,true);
        parent.getChildAt(position).setBackgroundColor(Color.RED);

        //String name = mBTDevicesArrayList.get(position).getName();
        //String address = mBTDevicesArrayList.get(position).getAddress();

        int rssi = 0;
        byte[] scanRecord ={0x01, 0x02, 0x03, 0x04};
        //ScanAllBTDevices = BT_TRY_TO_CONNECT;
        BluetoothLEHandler.getInstance().ConnectBTDevice(position);
       // processDeviceDiscovered(mBTDevicesArrayList.get(position).GetBTLE_Device(),rssi,scanRecord);
    }


    private void PulseTask(){

        Thread t=new Thread(){


            @Override
            public void run(){

                while(!isInterrupted()){

                    try {
                        Thread.sleep(1000);  //1000ms = 1 sec

                        runOnUiThread(new Runnable() {

                            @Override
                            public void run() {

                                /*
                                hrCounter++;

                                if (ScanAllBTDevices == BT_SCAN_ALL ){

                                    if (scanAllCounter < scanMaxCounter){
                                        scanAllCounter++;

                                        textViewHR.setText("State: BT_SCAN_ALL looking for bluetooth devices  " +
                                                "\nDebug scanAllCounter: " + String.valueOf(scanAllCounter)+ " / " + String.valueOf(scanMaxCounter));

                                    }
                                    else {
                                        //ScanAllBTDevices = false;
                                        StopBluetoothScan();
                                    }
                                }
                                else if (ScanAllBTDevices == BT_TRY_TO_CONNECT ){
                                    textViewHR.setText("State: BT_TRY_TO_CONNECT"
                                            + "\nDebug Counter: " + String.valueOf(hrCounter));
                                }

                                else if (ScanAllBTDevices == BT_CONNECTED ){

                                    textViewHR.setText("State: BT_CONNECTED  Pulssi: " + String.valueOf(hrRate)
                                            + "\nDebug Counter: " + String.valueOf(hrCounter));

                                    //hrCounter++;
                                }
                                else if (ScanAllBTDevices == BT_NONE ) {
                                    textViewHR.setText("State: BT_NONE 'getInstance'" + String.valueOf(BluetoothLEHandler.getInstance().GetHRRate())
                                            + "\nDebug Counter: " + String.valueOf(hrCounter));
                               }
                               else{
                                    textViewHR.setText("State: unknown. ScanAllBTDevices value: " +String.valueOf(ScanAllBTDevices)
                                            + "\nDebug Counter: " + String.valueOf(hrCounter));
                                }
                                */
                                textViewHR.setText(BluetoothLEHandler.getInstance().getDebugInfo());

                            }
                        }); // End of runOnUiThread

                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                } // end of while
            }
        }; // End of Thread

        t.start();

    }

}

